document.addEventListener("DOMContentLoaded", function () {
    // 💡 장고 static 폴더 구조에 맞게 배경 이미지 파일 경로를 수정합니다.
    const pageBackgrounds = {
        'index.html': [
            "url('/static/css/images/bg-index-c5.png')",
            "url('/static/css/images/bg-index-c6.png')",
            "url('/static/css/images/bg-index-c7.png')"
        ],
        'search-room.html': [
            "url('/static/css/images/bg-search-c3.png')",
            "url('/static/css/images/bg-search-c1.png')"
        ]
    };

    // 장고 URL 패스 체계에 맞춰 분기하도록 현재 경로 추출 로직 보완
    let pathSegments = window.location.pathname.split('/');
    let currentPageName = pathSegments[pathSegments.length - 2] || 'index.html'; 
    let bgTargetPage = 'index.html';

    if (currentPageName === 'search') {
        bgTargetPage = 'search-room.html';
    } else if (currentPageName === 'create') {
        bgTargetPage = 'search-room.html';
    } else if (currentPageName === 'login' || currentPageName === 'signup') {
        bgTargetPage = 'index.html';
    }

    const backgroundImages = pageBackgrounds[bgTargetPage] || pageBackgrounds['index.html'];
    const storageKey = 'bgIndex_' + bgTargetPage;
    const savedBgIndex = localStorage.getItem(storageKey);
    let currentBgIndex = savedBgIndex ? parseInt(savedBgIndex) : 0;

    if (currentBgIndex >= backgroundImages.length) {
        currentBgIndex = 0;
    }

    // 초기 배경화면 적용
    document.body.style.setProperty('--bg-image', backgroundImages[currentBgIndex]);

    // 현재 활성화된 메뉴 하이라이트(active) 처리
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        if (window.location.pathname.includes(linkHref)) {
            link.classList.add('active');
        }
    });

    // LocalStorage 기반 로그인 세션 연동 상태 확인
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

    if (isLoggedIn) {
        const loginSection = document.getElementById('login-section');
        const userSection = document.getElementById('user-section');

        if (loginSection) loginSection.style.display = 'none';
        if (userSection) {
            userSection.style.display = 'block';
            const savedName = localStorage.getItem('userName');
            const userNicknameEl = document.getElementById('user-nickname');
            
            if (savedName && userNicknameEl) {
                let displayName = savedName;
                if (displayName.length > 12) {
                    displayName = displayName.substring(0, 12) + '...';
                }
                
                const safeName = displayName.replace(/[&<>'"]/g, function (tag) {
                    const charsToReplace = { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' };
                    return charsToReplace[tag] || tag;
                });
                userNicknameEl.innerHTML = `${safeName}<br>Welcome!`;
            }
        }
    }

    // 로그아웃 버튼 이벤트 처리
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function (event) {
            event.preventDefault();
            
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('accessToken');
            localStorage.removeItem('userName');
            
            window.location.replace('/chat/'); 
        });
    }

    // 테마 토글 버튼 클릭 시 배경 이미지 돌려가며 바꾸는 핵심 로직
    const themeButtons = document.querySelectorAll('.theme-toggle-btn');
    themeButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            currentBgIndex = (currentBgIndex + 1) % backgroundImages.length;
            document.body.style.setProperty('--bg-image', backgroundImages[currentBgIndex]);
            localStorage.setItem(storageKey, currentBgIndex);
        });
    });
});