document.addEventListener("DOMContentLoaded", function () {
    const currentPath = window.location.pathname;

    // 1. 네비게이션 링크 매핑 고정
    const navbarBrand = document.querySelector('.navbar-brand');
    if (navbarBrand) {
        navbarBrand.setAttribute('href', '/');
    }

    const browseRoomsLinks = document.querySelectorAll('a[href*="search-room.html"], a[href="/chat/"]');
    browseRoomsLinks.forEach(link => { link.setAttribute('href', '/chat/'); });

    const hostRoomLinks = document.querySelectorAll('a[href*="create-room.html"], a[href="/chat/create/"]');
    hostRoomLinks.forEach(link => { link.setAttribute('href', '/chat/create/'); });

    const aboutLinks = document.querySelectorAll('a[href*="about.html"], a[href="/chat/about/"]');
    aboutLinks.forEach(link => { link.setAttribute('href', '/chat/about/'); });

    // 2. 로그인 상태 동적 UI 처리
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const loginSection = document.getElementById('login-section');
    const userSection = document.getElementById('user-section');
    const userNicknameEl = document.getElementById('user-nickname');

    if (isLoggedIn) {
        if (loginSection) loginSection.style.display = 'none';
        if (userSection) userSection.style.display = 'block';
        const myName = localStorage.getItem('userName');
        if (myName && userNicknameEl) {
            userNicknameEl.innerHTML = `Welcome, ${myName}!`;
        }
    } else {
        if (loginSection) loginSection.style.display = 'block';
        if (userSection) userSection.style.display = 'none';
    }

    // 3. 로그아웃 처리
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function (event) {
            event.preventDefault();
            localStorage.clear();
            window.location.replace('/');
        });
    }

    // 4. 🎯 [달 아이콘 배경 전환 완벽 보장 로직]
    const pageBackgrounds = {
        'index': [
            "/static/bg-index-c5.png",
            "/static/bg-index-c6.png",
            "/static/bg-index-c7.png"
        ],
        'search': [
            "/static/bg-search-c3.png",
            "/static/bg-search-c1.png"
        ]
    };

    let bgTargetPage = 'index'; 
    if (currentPath.includes('/create/')) {
        bgTargetPage = 'search';
    } else if (currentPath === '/chat/' || currentPath === '/chat') {
        bgTargetPage = 'search';
    } else if (currentPath.includes('/about/')) {
        bgTargetPage = 'search';
    }

    const backgroundImages = pageBackgrounds[bgTargetPage];
    const storageKey = 'bgIndex_' + bgTargetPage;
    let currentBgIndex = parseInt(localStorage.getItem(storageKey), 10) || 0;

    // 강력한 배경 이미지 주입 함수 (!important 강제 적용)
    function applyBackgroundImage(imgUrl) {
        if (!imgUrl) return;
        document.body.style.setProperty('--bg-image', `url('${imgUrl}')`, 'important');
        document.body.style.setProperty('background-image', `url('${imgUrl}')`, 'important');
    }

    // 초기 상태 배경 화면 렌더링
    if (backgroundImages && backgroundImages[currentBgIndex]) {
        applyBackgroundImage(backgroundImages[currentBgIndex]);
    }

    // 💡 HTML에 있는 모든 달 모양 버튼(.theme-toggle-btn)을 노드로 덮어씌우지 않고 정석대로 이벤트를 걸어줌
    const themeButtons = document.querySelectorAll('.theme-toggle-btn');
    
    themeButtons.forEach(btn => {
        // 아이콘은 어떤 상황에서도 무조건 달 모양 고정
        const icon = btn.querySelector('i');
        if (icon) {
            icon.className = 'bi bi-moon-fill';
        }

        // 클릭 이벤트 리스너 순수 등록 (버튼 복사로 속성이 날아가는 버그 방지)
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation(); // 이벤트 버블링 차단
            
            if (!backgroundImages || backgroundImages.length === 0) return;

            // 다음 배경 인덱스로 롤링
            currentBgIndex = (currentBgIndex + 1) % backgroundImages.length;
            applyBackgroundImage(backgroundImages[currentBgIndex]);
            localStorage.setItem(storageKey, currentBgIndex);

            // 💡 클릭한 후에도 모든 버튼의 아이콘 모양이 '달' 상태를 유지하도록 리셋
            document.querySelectorAll('.theme-toggle-btn i').forEach(i => {
                i.className = 'bi bi-moon-fill';
            });
        });
    });
});